# Business Rules Encoded in the Generator

Each rule below is implemented as a *probabilistic influence* (via weighted sums and/or
logistic transforms plus noise), not a hard deterministic cutoff. Column names refer to
`dataset.csv` / `data_dictionary.csv`.

| # | Rule | Implementation |
|---|---|---|
| 1 | Higher ATS score generally increases shortlist probability. | `Shortlisted` sampled from `sigmoid(z(ATS_Score) * 1.1 - 0.4)`, conditioned on `Passed_Resume_Screening`. |
| 2 | Higher keyword match improves ATS score. | `ATS_Score` includes `0.35 * Keyword_Match_Pct` as its largest single weighted term. |
| 3 | Better communication increases HR interview performance. | `HR_Interview_Score = 0.6 * Communication_Score + 0.2 * Behavioral_Interview_Score + noise`. |
| 4 | Strong coding score improves technical interview performance. | `Technical_Interview_Score = 0.55 * Coding_Test_Score + 0.25 * ATS_Compatibility_Score + noise`. |
| 5 | Relevant experience influences hiring more than total experience. | `ATS_Score` uses `Relevant_Experience_Years` directly; `Years_Experience` only enters indirectly through `skill_base`/salary, with a smaller effective weight on final outcomes. |
| 6 | Top-tier universities slightly improve interview probability but do not dominate outcomes. | `University_Tier` contributes a modest, capped `tier_num * 15` term (~10% weight) inside `ATS_Score`; it also nudges `CGPA` upward, but assessment/interview scores are driven mainly by test performance, not university tier. |
| 7 | Higher expected salary reduces offer probability when significantly above market. | `salary_penalty` activates only when `Expected_Salary / market_rate > 1.25`, then subtracts from `Offer_Probability`'s logit and from `hiring_decision_prob`. |
| 8 | Long career gaps slightly reduce ATS score unless offset by certifications or projects. | `gap_penalty = 4.0 (if gap) - 0.3 * Certifications_Count - 0.1 * Open_Source_Contributions`, subtracted from `ATS_Score`. |
| 9 | GitHub, portfolio, and open-source contributions improve technical roles. | `GitHub_Available`/`Portfolio_Available` probabilities scale with `skill_base`; `Open_Source_Contributions` feeds into the `ATS_Score` gap offset and is elevated for technical roles via `is_tech_role`. |
| 10 | AI and LLM skills increase demand for AI-related jobs. | `AI_Skill_Level`, `ML_Skill_Level`, `DL_Skill_Level`, `GenAI_Skill_Level` are all centered higher when `is_ai_role` (Data Scientist / ML Engineer / AI Researcher / Cloud Architect) is true, which flows through to `Technical_Interview_Score` and `ATS_Score` for those roles. |
| 11 | Leadership experience positively influences managerial positions. | `Manager_Interview_Score` adds `0.3 * Leadership_Experience * 15`; `Offer_Probability` adds a bonus term `0.3 * Leadership_Experience * is_managerial`. |
| 12 | Promotion history correlates with predicted performance. | `Predicted_Performance` includes `0.10 * Promotion_History_Count * 10`; `Promotion_Probability` also depends on `Promotion_History_Count`. |
| 13 | Retention probability inversely relates to attrition risk. | `Retention_Probability = 1 - Attrition_Risk + small noise`, clipped to [0, 1]. |

## Additional embedded consistency rules (beyond the spec's list)

- **Funnel monotonicity:** every later-stage boolean requires the prior stage boolean to be
  `True` (e.g., `HR_Interview_Done` implies `Manager_Interview_Done`).
- **Role-conditioned coding assessment:** `Coding_Test_Score` and `Coding_Test_Taken` are
  scaled down/skipped more often for non-technical roles (e.g., Sales, HR, Finance roles).
- **Education-consistent categorical sampling:** `Degree` is drawn only from the set of
  degrees valid for the sampled `Education_Level`; `City` is drawn only from cities that
  exist for the sampled `Country`.
- **Salary realism:** `Current_Salary` is a function of experience, education tier,
  university tier, and industry multiplier (e.g., Technology and Finance pay more than
  Education or Government, on average), with additional log-normal-like noise.
- **Seasonality:** application volume is weighted higher in Jan–Mar and Sep–Oct
  (`month_weights`), consistent with common corporate hiring cycles.

## Deliberate non-determinism

All of the rules above are expressed as **weights inside a noisy linear/logistic model**,
not as `if/else` hard rules. This means:
- Two otherwise-identical applicants can get different outcomes.
- Correlations are visible in aggregate statistics (Pearson correlation, group means,
  logistic-regression coefficients) but no single feature perfectly predicts any target.
- This makes the dataset usable for realistic model benchmarking — a well-tuned model can
  recover the underlying rules, but a naive rule-based classifier will not reach 100%
  accuracy, mirroring real-world hiring data.
