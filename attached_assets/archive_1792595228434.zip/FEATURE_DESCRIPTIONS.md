# Feature Descriptions (by Block)

Full column-level reference lives in `data_dictionary.csv`; this document gives the
narrative/grouped view.

## 1. Application Metadata (4 columns)
`Application_Date`, `Application_Year`, `Application_Quarter`, `Source_Channel`

Captures *when* and *how* the candidate applied. Application volume is seasonally weighted
(higher in Q1 and Q3/Q4) to simulate realistic corporate hiring cycles across 2023–2026.

## 2. Candidate Profile (27 columns)
Demographics (`Age`, `Gender`, `Country`, `City`, `Nationality`), education
(`Education_Level`, `Degree`, `Major`, `University_Tier`, `CGPA`, `Graduation_Year`),
career history (`Employment_Status`, `Years_Experience`, `Relevant_Experience_Years`,
`Career_Gap`, `Career_Gap_Duration_Months`, `Promotion_History_Count`,
`Leadership_Experience`, `Team_Size_Managed`), compensation
(`Current_Salary`, `Expected_Salary`, `Salary_Increase_Pct`, `Notice_Period_Days`), and
role context (`Current_Company_Size`, `Industry`, `Job_Role`, `Remote_Experience`).

This block is the foundation that most downstream skill, resume, and assessment features
are conditioned on.

## 3. Technical Skills (19 columns)
Programming languages, frameworks, cloud/database/version-control familiarity, and a
dedicated AI/LLM sub-block (`AI_Skill_Level`, `ML_Skill_Level`, `DL_Skill_Level`,
`GenAI_Skill_Level`, `LLM_Experience_Years`, `Prompt_Engineering_Skill`,
`RAG_Experience`, `Fine_Tuning_Experience`, `Vector_DB_Experience`). All are driven by a
shared latent `skill_base` composite so a strong candidate tends to show elevated,
correlated scores across the board rather than one random skill and nine average ones.

## 4. Resume Features (19 columns)
Resume-quality signals an ATS or recruiter would extract: `Resume_Length_Words`,
`Grammar_Score`, `Formatting_Score`, `Action_Verb_Score`, `Keyword_Match_Pct`,
`ATS_Compatibility_Score`, `Resume_Quality_Score`, plus evidence-of-work signals
(`GitHub_Available`, `Portfolio_Available`, `LinkedIn_Available`, `Personal_Website`,
`Open_Source_Contributions`, `Research_Publications`, `Patents`, `Awards`,
`Volunteer_Work`, `Hackathons`, `Certifications_Count`,
`Certification_Relevance_Score`).

## 5. Assessment Scores (15 columns)
Every formal evaluation stage in the pipeline: `Aptitude_Test_Score`,
`Logical_Reasoning_Score`, `Coding_Test_Score`, `SQL_Test_Score`,
`Communication_Score`, `Presentation_Score`, `Behavioral_Interview_Score`,
`Technical_Interview_Score`, `HR_Interview_Score`, `Manager_Interview_Score`,
`Problem_Solving_Score`, `Leadership_Score`, `Critical_Thinking_Score`,
`Creativity_Score`, `Culture_Fit_Score`. These cascade — e.g., `Technical_Interview_Score`
partly depends on `Coding_Test_Score`, `HR_Interview_Score` partly depends on
`Communication_Score`.

## 6. Behavioral Traits (10 columns)
Soft-skill/psychometric-style indicators: `Learning_Agility_Score`, `Adaptability_Score`,
`Emotional_Intelligence_Score`, `Stress_Management_Score`, `Teamwork_Score`,
`Ownership_Score`, `Innovation_Score`, `Integrity_Score`, `Work_Ethic_Score`,
`Time_Management_Score`.

## 7. Pipeline Stage Flags (10 columns)
Boolean funnel checkpoints, strictly nested (each requires the prior stage to be `True`):
`Passed_Resume_Screening` → `Shortlisted` → `Technical_Assessment_Taken` →
`Coding_Test_Taken` → `Communication_Interview_Done` → `Behavioral_Interview_Done` →
`Manager_Interview_Done` → `HR_Interview_Done` → `Salary_Negotiation_Stage`, plus
`Days_In_Pipeline` (total elapsed time).

## 8. Hiring Outputs / Targets (11 columns)
The modeling targets: `ATS_Score`, `Resume_Rank`, `Interview_Probability`,
`Offer_Probability`, `Predicted_Performance`, `Probation_Success_Probability`,
`Promotion_Probability`, `Retention_Probability`, `Attrition_Risk`, `Hiring_Decision`,
`Final_Hiring_Status`.
